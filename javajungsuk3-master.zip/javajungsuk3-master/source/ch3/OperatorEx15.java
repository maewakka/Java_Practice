class OperatorEx15 { 
      public static void main(String[] args) { 
            char lowerCase = 'a'; 
            char upperCase = (char)(lowerCase - 32); 

            System.out.println(upperCase); 
      } 
} 
